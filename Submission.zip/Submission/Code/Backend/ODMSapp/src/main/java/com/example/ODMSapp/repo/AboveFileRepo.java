package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ODMSapp.entity.Above25Files;

@Repository
public interface AboveFileRepo extends JpaRepository<Above25Files, Long> {

}
