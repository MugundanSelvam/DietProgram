package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ODMSapp.entity.Above25Users;

public interface AuserRepo extends JpaRepository<Above25Users, String> {

}
