package com.example.ODMSapp;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.ODMSapp.entity.Above25;
import com.example.ODMSapp.entity.Above25Files;
import com.example.ODMSapp.entity.Above25Users;
import com.example.ODMSapp.entity.Below25;
import com.example.ODMSapp.entity.Below25Files;
import com.example.ODMSapp.entity.Below25Users;
import com.example.ODMSapp.entity.NewUser;
import com.example.ODMSapp.entity.UserApproval;
import com.example.ODMSapp.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class ODMSController {

	@Autowired
	private UserService userService;
	
	
	@GetMapping("/logincheck/{id}/{pw}")
	public int logincheck(@PathVariable("id") String id, @PathVariable("pw") String pw)
	{
		return userService.credcheck(id,pw);	
	}
	
	@GetMapping("/type/{mail}")
	public int checktype(@PathVariable("mail")String mail) 
	{
		return userService.checktype(mail);
	}
	
	@PostMapping("/addUser")
	public boolean addinguser(@RequestBody NewUser user) {
		return userService.adduser(user);
	}
	
	@GetMapping("/allusers")
	public List<NewUser> allusers() {
		return userService.allusers();
	}
	
	@GetMapping("/requsers")
	public List<UserApproval> requsers(){
		return userService.requsers();
	}
	
	@PostMapping("/approve")
	public boolean approve(@RequestBody UserApproval user) {
		return userService.approve(user);
	}
	
	@PostMapping("/reject")
	public boolean reject(@RequestBody UserApproval user) {
		return userService.reject(user);
	}
	
	@GetMapping("/promote/{mail}/{type}")
	public boolean promote(@PathVariable("mail")String mail,@PathVariable("type")String type) {
		return userService.promote(mail,type);
	}
	
	@PostMapping("/below")
	public boolean storingbelow(@RequestBody Message message) {
		return userService.storingbelow(message);
	}
	
	@GetMapping("/deletebmsg/{id}")
	public boolean deletingbmsg(@PathVariable("id")int number) {
		return userService.deletebelow(number);
	}
	
	@GetMapping("/readbelow")
	public List<Below25> readingbelow(){
		return userService.readingbelow();
	}
	
	
	@GetMapping("/buser")
	public List<Below25Users> getbelowusers(){
		return userService.getbelowusers();
	}
	
	@PostMapping("/above")
	public boolean storingabove(@RequestBody Message message) {
		return userService.storingabove(message);
	}
	
	@GetMapping("/deleteamsg/{id}")
	public boolean deletingamsg(@PathVariable("id")int number) {
		return userService.deleteabove(number);
	}
	
	@GetMapping("/readabove")
	public List<Above25> readingabove(){
		return userService.readingabove();
	}
	
	
	@GetMapping("/auser")
	public List<Above25Users> getaboveusers(){
		return userService.getaboveusers();
	}
	
	
	@GetMapping("/delete/{mail}")
	public boolean delete(@PathVariable("mail") String mail) {
		return userService.delete(mail);
	}
	
	@GetMapping("/detail/{mail}")
	public Optional<NewUser> detail(@PathVariable("mail") String mail) {
		return userService.detail(mail);
	}
	
	
	
	//File Related
	
	@PostMapping("/abovefile/upload")
    public String uploadAbovetFile(@RequestBody MultipartFile file) {
        return userService.uploadAboveFile(file)   ;
    }
	
	@GetMapping("/abovefile/all")
	public List<Above25Files> getAboveFiles() {
	    return userService.getAboveFiles();
	}
	  
	  
	@GetMapping("/abovefile/{id}")
	public ResponseEntity<byte[]> getAboveFile(@PathVariable Long id) {
	    return userService.getAboveFile(id);
	}
	  

	@GetMapping("/abovefiledelete/{id}")
	public void deleteAboveFile(@PathVariable Long id) {
	    userService.deleteAboveFile(id);
	}
	
	@PostMapping("/belowfile/upload")
    public String uploaBelowFile(@RequestBody MultipartFile file) {
        return userService.uploadBelowFile(file)   ;
    }
	
	@GetMapping("/belowfile/all")
	public List<Below25Files> getBelowFiles() {
	    return userService.getBelowFiles();
	}
	  
	  
	@GetMapping("/belowfile/{id}")
	public ResponseEntity<byte[]> getBelowFile(@PathVariable Long id) {
	    return userService.getBelowFile(id);
	}
	  

	@GetMapping("/belowfiledelete/{id}")
	public void deleteBelowFile(@PathVariable Long id) {
	    userService.deleteBelowFile(id);
	}

	
}
