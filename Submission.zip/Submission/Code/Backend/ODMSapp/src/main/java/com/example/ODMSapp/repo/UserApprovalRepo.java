package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ODMSapp.entity.UserApproval;

@Repository
public interface UserApprovalRepo extends JpaRepository<UserApproval, String> {

}
