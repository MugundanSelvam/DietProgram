package com.example.ODMSapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import com.example.ODMSapp.Message;
import com.example.ODMSapp.entity.Above25;
import com.example.ODMSapp.entity.Above25Files;
import com.example.ODMSapp.entity.Above25Users;
import com.example.ODMSapp.entity.Below25;
import com.example.ODMSapp.entity.Below25Files;
import com.example.ODMSapp.entity.Below25Users;
import com.example.ODMSapp.entity.NewUser;
import com.example.ODMSapp.entity.UserApproval;

public interface UserService {

	public int credcheck(String id,String pw);
	
	public int checktype(String mail);
	
	public boolean adduser(NewUser user);
	
	public List<NewUser> allusers();
	
	public List<UserApproval> requsers();
	
	public boolean approve(UserApproval user);
	
	public boolean reject(UserApproval user);
	
	public boolean storingbelow(Message m);
	
	public boolean deletebelow(int number);
	
	public List<Below25> readingbelow();
	
	public List<Below25Users> getbelowusers();
	
    public boolean storingabove(Message m);
    
    public boolean deleteabove(int number);
	
	public List<Above25> readingabove();
	
	public List<Above25Users> getaboveusers();
	
	public boolean delete(String mail);
	
	public Optional<NewUser> detail(String mail);
	
	public boolean promote(String mail, String type);
	
	//For File Operations
	
	public String uploadAboveFile(MultipartFile file);
	
	public List<Above25Files> getAboveFiles();
	
	public ResponseEntity<byte[]> getAboveFile(Long id);
	
	public void deleteAboveFile(Long id);
	
    public String uploadBelowFile(MultipartFile file);
	
	public List<Below25Files> getBelowFiles();
	
	public ResponseEntity<byte[]> getBelowFile(Long id);
	
	public void deleteBelowFile(Long id);
		
	
}
