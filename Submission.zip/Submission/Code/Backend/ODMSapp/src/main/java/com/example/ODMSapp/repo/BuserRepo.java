package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ODMSapp.entity.Below25Users;

public interface BuserRepo extends JpaRepository<Below25Users, String> {

}
