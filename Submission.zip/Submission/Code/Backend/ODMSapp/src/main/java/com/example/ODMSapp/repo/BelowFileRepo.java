package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ODMSapp.entity.Below25Files;


@Repository
public interface BelowFileRepo extends JpaRepository<Below25Files,Long> {

}
