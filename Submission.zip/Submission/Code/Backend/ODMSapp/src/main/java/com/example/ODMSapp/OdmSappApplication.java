package com.example.ODMSapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OdmSappApplication {

	public static void main(String[] args) {
		SpringApplication.run(OdmSappApplication.class, args);
	}

}
