package com.example.ODMSapp.service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.ODMSapp.Message;
import com.example.ODMSapp.entity.Above25;
import com.example.ODMSapp.entity.Above25Files;
import com.example.ODMSapp.entity.Above25Users;
import com.example.ODMSapp.entity.Below25;
import com.example.ODMSapp.entity.Below25Files;
import com.example.ODMSapp.entity.Below25Users;
import com.example.ODMSapp.entity.NewUser;
import com.example.ODMSapp.entity.UserApproval;
import com.example.ODMSapp.entity.UserCredentials;
import com.example.ODMSapp.repo.AboveFileRepo;
import com.example.ODMSapp.repo.Aboverepo;
import com.example.ODMSapp.repo.AuserRepo;
import com.example.ODMSapp.repo.BelowFileRepo;
import com.example.ODMSapp.repo.Belowrepo;
import com.example.ODMSapp.repo.BuserRepo;
import com.example.ODMSapp.repo.NewUserRepo;
import com.example.ODMSapp.repo.UserApprovalRepo;
import com.example.ODMSapp.repo.UserCredntialRepo;

@Service
public class UserServiceImpl implements UserService {

	private String loggedinuser;
	
	@Autowired
	private UserCredntialRepo repo;
		
	@Autowired
	private UserApprovalRepo userrepo;
	
	@Autowired
	private NewUserRepo newrepo;
	
	@Autowired
	private EmailService emailservice;
	
	@Autowired
	private Belowrepo brepo;
	
	@Autowired
	private BuserRepo burepo;
	
	@Autowired
	private Aboverepo arepo;
	
	@Autowired
	private AuserRepo aurepo;
	
	@Autowired
	private AboveFileRepo abovefilerepo;
	
	@Autowired
	private BelowFileRepo belowfilerepo;
	
	@Override
	public int credcheck(String id,String pw) {
		try {	
		UserCredentials user = repo.getOne(id);
		loggedinuser = user.getEmail();
		if(user.getPassword().equals(pw))
		{
			if(user.getType().equals("admin")) {
				return 1;
			}
			else if(user.getType().equals("user"))
			{
				return 2;
			}
			else
			{
				return 5;
			}
		}
		return 3;
		}
		catch(Exception e)
		{
		return 4;
		}
	}
    
	@Override
	public int checktype(String mail) {
		if(burepo.existsById(mail))
		{
			return 1;
		}
		else
		{
			return 0;	
		}
	}
	
	
	@Override
	public boolean adduser(NewUser user) {
		newrepo.save(user);
		UserApproval up = new UserApproval();
		up.setFn(user.getFn());
		up.setLn(user.getLn());
		up.setMail(user.getMail());
		userrepo.save(up);
		return true;
	}
	
	@Override
	public List<NewUser> allusers()
	{
	 return newrepo.findAll();
	}
	
	@Override
	public List<UserApproval> requsers()
	{
	 return userrepo.findAll();
	}
	
	@Override
	public boolean approve(UserApproval user) {
		UserCredentials uc = new UserCredentials();
		NewUser nu = newrepo.getOne(user.getMail());
		String pw = user.getFn()+nu.getAge();
		uc.setEmail(user.getMail());
		uc.setFirstName(user.getFn());
		uc.setLastName(user.getLn());
		uc.setPassword(pw);
		uc.setType("user");
		repo.save(uc);
		userrepo.deleteById(user.getMail());
		
		int weight=nu.getWeight();
		double height = (nu.getHeight()*0.01)*(nu.getHeight()*0.01);
		double bmi=weight/height;
		if(bmi<25)
		{
			Below25Users buser=new Below25Users();
			buser.setMail(user.getMail());
			burepo.save(buser);
		}else {
			Above25Users auser=new Above25Users();
			auser.setMail(user.getMail());
			aurepo.save(auser);
		}
		
		String to = user.getMail();
		String subject = "REG : Diet Program Registration";
		String text ="Hi "+user.getFn()+", your Registration has been approved. Kindly login with your MailID and Password: "+pw;
		emailservice.sendSimpleMessage(to, subject, text);
				
		return true;
	}
	
	@Override
	public boolean reject(UserApproval user) {
		newrepo.deleteById(user.getMail());
		userrepo.deleteById(user.getMail());
		
		String to = user.getMail();
		String subject = "REG : Diet Program Registration";
		String text ="Hi "+user.getFn()+", Sorry..!! Your request has been rejected"; 
		emailservice.sendSimpleMessage(to, subject, text);
		return true;
	}
	
	@Override
	public boolean promote(String mail, String type) {
		UserCredentials usercred=repo.getOne(mail);
		usercred.setType(type);
		repo.deleteById(mail);
		repo.save(usercred);
		return true;
	}

	@Override
	public boolean storingbelow(Message m) {
	    Below25 message = new Below25();
	    SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm");
	    Date now = new Date();
	    String time = sdfDate.format(now);
	    message.setMessage(m.getMessage());
	    message.setSender(loggedinuser);
	    message.setTime(time);
	    brepo.save(message);
		return true;
	}
	
	@Override
	public boolean deletebelow(int number) {
		brepo.deleteById(number);
		return true;
	}
	
	@Override
	public List<Below25> readingbelow(){
		return brepo.findAll();
	}
	
	@Override
	public List<Below25Users> getbelowusers(){
		return burepo.findAll();
	}
	
	@Override
	public boolean storingabove(Message m) {
	    Above25 message = new Above25();
	    SimpleDateFormat sdfDate = new SimpleDateFormat("dd-MM-yyyy HH:mm");
	    Date now = new Date();
	    String time = sdfDate.format(now);
	    message.setMessage(m.getMessage());
	    message.setSender(loggedinuser);
	    message.setTime(time);
	    arepo.save(message);
		return true;
	}
	
	@Override
	public boolean deleteabove(int number) {
		arepo.deleteById(number);
		return true;
	}
	
	@Override
	public List<Above25> readingabove(){
		return arepo.findAll();
	}
	
	@Override
	public List<Above25Users> getaboveusers(){
		return aurepo.findAll();
	}
	
	
	@Override
	public boolean delete(String mail) {
		
		if(burepo.existsById(mail)) {
		 burepo.deleteById(mail);	
		}
		else if(aurepo.existsById(mail)) {
		 aurepo.deleteById(mail);	
		}		
		newrepo.deleteById(mail);
		repo.deleteById(mail);;
		return true;
	}
	
	@Override
	public Optional<NewUser> detail(String mail) {
		return newrepo.findById(mail);
	}
	
	//File Related 
	
	public String uploadAboveFile(MultipartFile file) {
		try 
	      {
	       	Above25Files filetostore = new Above25Files(file.getOriginalFilename(), file.getContentType(), file.getBytes());
	    	abovefilerepo.save(filetostore);
	        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
	      }
	      catch (Exception e)
	      {
	      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
	      }
	}
	
	public List<Above25Files> getAboveFiles(){
		return abovefilerepo.findAll();
	}
	
	public ResponseEntity<byte[]> getAboveFile(Long id){
		Optional<Above25Files> fileOptional = abovefilerepo.findById(id);
		    
		    if(fileOptional.isPresent()) {
		      Above25Files file = fileOptional.get();
		      return ResponseEntity.ok()
		          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
		          .contentType(MediaType.parseMediaType(file.getMimetype()))
		          .body(file.getPic());  
		    }
		return ResponseEntity.status(404).body(null);
	}
	
	public void deleteAboveFile(Long id) {
		abovefilerepo.deleteById(id);
	}
	
	
	public String uploadBelowFile(MultipartFile file) {
		try 
	      {
	       	Below25Files filetostore = new Below25Files(file.getOriginalFilename(), file.getContentType(), file.getBytes());
	    	belowfilerepo.save(filetostore);
	        return "File uploaded successfully! -> filename = " + file.getOriginalFilename();
	      }
	      catch (Exception e)
	      {
	      return "FAIL! Maybe You had uploaded the file before or the file's size > 500KB";
	      }
	}
	
	public List<Below25Files> getBelowFiles(){
		return belowfilerepo.findAll();
	}
	
	public ResponseEntity<byte[]> getBelowFile(Long id){
		Optional<Below25Files> fileOptional = belowfilerepo.findById(id);
		    
		    if(fileOptional.isPresent()) {
		      Below25Files file = fileOptional.get();
		      return ResponseEntity.ok()
		          .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + file.getName() + "\"")
		          .contentType(MediaType.parseMediaType(file.getMimetype()))
		          .body(file.getFile());  
		    }
		return ResponseEntity.status(404).body(null);
	}
	
	public void deleteBelowFile(Long id) {
		belowfilerepo.deleteById(id);
	}

	
	
	
}
