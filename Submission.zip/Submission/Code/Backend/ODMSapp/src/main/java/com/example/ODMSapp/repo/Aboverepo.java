package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ODMSapp.entity.Above25;

public interface Aboverepo extends JpaRepository<Above25, Integer> {

}
