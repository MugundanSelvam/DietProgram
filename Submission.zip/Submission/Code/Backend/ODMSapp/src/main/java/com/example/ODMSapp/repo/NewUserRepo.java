package com.example.ODMSapp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.ODMSapp.entity.NewUser;

@Repository
public interface NewUserRepo extends JpaRepository<NewUser, String> {

}
