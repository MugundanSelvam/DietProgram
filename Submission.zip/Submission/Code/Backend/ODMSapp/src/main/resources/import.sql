INSERT INTO Usercredentials (fn,ln,mail,pw,tp) VALUES ('Mugundan','Selvam','mugucodes@gmail.com','wipro@123','admin');
