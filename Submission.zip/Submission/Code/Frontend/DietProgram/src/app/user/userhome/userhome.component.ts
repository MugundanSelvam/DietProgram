import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userhome',
  templateUrl: './userhome.component.html',
  styleUrls: ['./userhome.component.css']
})
export class UserhomeComponent implements OnInit {

  above:boolean=true;
  below:boolean=true;

  constructor(private router:Router,private dietService:DietserviceService) { }

  ngOnInit() {
    this.dietService.checktype().subscribe(resp=>{
      if(resp==0){
        this.above=false;
      }else{
        this.below=false;
      }
    })
  }
 
  logout(){
    this.router.navigate(["/"]);
  }


}
