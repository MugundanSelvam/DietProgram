import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DietserviceService } from './../../dietservice.service';
import { Message } from './../../Message';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-below25',
  templateUrl: './below25.component.html',
  styleUrls: ['./below25.component.css']
})
export class Below25Component implements OnInit {

  private alltexts:Message[];
  fileUploads: Observable<string[]>;
  permission:string;
  private default:string;
  selectedFiles: FileList;
  currentFileUpload: File;
  
  loggedin:string;
  showFile = false;

  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
    this.permission=this.dietservice.getPermission();
    this.loggedin=this.dietservice.getLoggedin();
    this.fileUploads = this.dietservice.getbelowFiles();
    this.dietservice.getb25().subscribe(resp=>{
    this.alltexts=resp;
  });
  
  }

  submit(message:string)
  {
      this.dietservice.addb25(message).subscribe(resp=>{
        if(resp){
          this.default='';      
          this.ngOnInit();
        }
      });
  }

  deletemsg(id:number){
    if(confirm("Are you sure, you want to delete this Message ?")) {
    this.dietservice.delb25(id).subscribe(resp=>{
      if(resp){
        this.ngOnInit();
      }
    });
  }
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 
  upload() {
    
 
    this.currentFileUpload = this.selectedFiles.item(0);
    this.dietservice.pushbelowfile(this.currentFileUpload).subscribe(event => {
      this.ngOnInit();
    });
    this.selectedFiles = undefined;
  }

  deletefile(id:number){
    if(confirm("Are you sure, you want to delete this file ?")) {
    this.dietservice.deletebelowfile(id).subscribe(resp=>{
        this.ngOnInit();
    });
   }
  }
}
