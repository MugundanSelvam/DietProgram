import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DietserviceService } from './../../dietservice.service';
import { Message } from './../../Message';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-above25',
  templateUrl: './above25.component.html',
  styleUrls: ['./above25.component.css']
})
export class Above25Component implements OnInit {

  private alltexts:Message[];
  fileUploads: Observable<string[]>;
  permission:string;
  private default:string;
  selectedFiles: FileList;
  currentFileUpload: File;
  progress: { percentage: number } = { percentage: 0 };
  loggedin:string;
  showFile = false;


  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
    this.permission=this.dietservice.getPermission();
    this.loggedin=this.dietservice.getLoggedin();
    this.dietservice.geta25().subscribe(resp=>{
    this.alltexts=resp;
  });
  this.fileUploads = this.dietservice.getaboveFiles();
  }


  submit(message:string)
  {
      this.dietservice.adda25(message).subscribe(resp=>{
        if(resp){
          this.default='';      
          this.ngOnInit();
        }
      });
  }

  deletemsg(id:number){
    if(confirm("Are you sure, you want to delete this Message ?")) {
    this.dietservice.dela25(id).subscribe(resp=>{
      if(resp){
        this.ngOnInit();
      }
    });
   }
  }

  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 
  upload() {
    
 
    this.currentFileUpload = this.selectedFiles.item(0);
    this.dietservice.pushabovefile(this.currentFileUpload).subscribe(event => {
      this.ngOnInit();
    });
    this.selectedFiles = undefined;
  }

  deletefile(id:number){
    if(confirm("Are you sure, you want to delete this file ?")) {
    this.dietservice.deleteabovefile(id).subscribe(resp=>{
        this.ngOnInit();
    });
   }
  }

}
