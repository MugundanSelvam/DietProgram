import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserhomeComponent } from './userhome/userhome.component';
import { RouterModule } from '@angular/router';
import { Below25Component } from './below25/below25.component';
import { DefaultpageComponent } from './defaultpage/defaultpage.component';
import { Above25Component } from './above25/above25.component';



@NgModule({
  declarations: [UserhomeComponent, Below25Component, DefaultpageComponent, Above25Component],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'userhome',component:UserhomeComponent,
                       children:[
                         {path:'',component:DefaultpageComponent},
                         {path:'below25',component:Below25Component},
                         {path:'above25',component:Above25Component}
                       ]                        
    }
    ])
  ]
})
export class UserModule { }
