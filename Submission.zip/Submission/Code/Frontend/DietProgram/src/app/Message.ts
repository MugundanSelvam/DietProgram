export class Message{
    id:number;
    message:string;
}