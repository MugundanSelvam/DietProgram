export class NewUser{
    fn:string;
    ln:string;
    age:number; 
    gender:string; 
    phone:string; 
    mail:string; 
    addr:string; 
    city:string; 
    state:string; 
    country:string; 
    pin:number; 
    height:number; 
    weight:number; 
    diet:string; 
} 