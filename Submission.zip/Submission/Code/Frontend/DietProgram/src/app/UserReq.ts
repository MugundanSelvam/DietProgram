export class UserReq
{
    fn : string;
    ln : string;
    mail : string;
}