import { TestBed } from '@angular/core/testing';

import { DietserviceService } from './dietservice.service';

describe('DietserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: DietserviceService = TestBed.get(DietserviceService);
    expect(service).toBeTruthy();
  });
});
