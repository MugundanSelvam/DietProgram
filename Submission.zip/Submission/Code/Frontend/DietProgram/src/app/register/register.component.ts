import { DietserviceService } from './../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { NewUser } from '../NewUser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
 
  
  constructor(private userservice:DietserviceService, private router:Router) { }

  submit(newuser:NewUser){
       this.userservice.addUser(newuser).subscribe(resp=>{
       if(resp)  
       this.router.navigate(['/'])
     });
     
  }

}
