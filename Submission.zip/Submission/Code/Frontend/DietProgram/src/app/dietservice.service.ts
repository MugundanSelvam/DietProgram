import { Message } from './Message';
import { User } from './User';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpEvent, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NewUser } from './NewUser';
import { UserReq } from './UserReq';

@Injectable({
  providedIn: 'root'
})
export class DietserviceService {

  private baseurl : string;
  private loggedinuser : string;
  private loggedinuserpermission : string;

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http:HttpClient) { 
   this.baseurl = 'http://localhost:8080/ODMSapp';
  }

 checkcred(user:User):Observable<number>{
  const newUrl = `${this.baseurl}/logincheck/${user.email}/${user.pw}`
  this.loggedinuser=user.email;
  return this.http.get<number>(newUrl);
 }

 checktype():Observable<number>{
   const newurl =  `${this.baseurl}/type/${this.loggedinuser}`
   return this.http.get<number>(newurl);
 }

 setPermission(type:string){
  this.loggedinuserpermission=type;
 }

 getPermission():string{
   return this.loggedinuserpermission;
 }

 getLoggedin():string{
   return this.loggedinuser;
 }

 addUser(newuser:NewUser):Observable<boolean>{
  const newurl = `${this.baseurl}/addUser`;
  return this.http.post<boolean>(newurl,newuser,this.httpOptions);
 }

 getallusers():Observable<NewUser[]>{
  const newurl = `${this.baseurl}/allusers`;
  return this.http.get<NewUser[]>(newurl);
 }
 
 getreq():Observable<UserReq[]>{
  const newurl = `${this.baseurl}/requsers`;
  return this.http.get<UserReq[]>(newurl);
 }

 approve(user:UserReq):Observable<boolean>{
  const newurl = `${this.baseurl}/approve`;
  return this.http.post<boolean>(newurl,user,this.httpOptions);
 }

 reject(user:UserReq):Observable<boolean>{
  const newurl = `${this.baseurl}/reject`;
  return this.http.post<boolean>(newurl,user,this.httpOptions);
 }

 promote(mail:string,type:string):Observable<boolean>{
  const newurl = `${this.baseurl}/promote/${mail}/${type}`;
  return this.http.get<boolean>(newurl);
 }

 

 addb25(message:string):Observable<boolean>{
  const newurl = `${this.baseurl}/below`;
  return this.http.post<boolean>(newurl,message,this.httpOptions);
 }

 getb25():Observable<Message[]>{
  const newurl = `${this.baseurl}/readbelow`;
  return this.http.get<Message[]>(newurl);
 }

 delb25(id:number):Observable<boolean>{
  const newurl = `${this.baseurl}/deletebmsg/${id}`;
  return this.http.get<boolean>(newurl);
 }

 getbuser():Observable<User[]>{
  const newurl = `${this.baseurl}/buser`;
  return this.http.get<User[]>(newurl);
 }

 adda25(message:string):Observable<boolean>{
  const newurl = `${this.baseurl}/above`;
  return this.http.post<boolean>(newurl,message,this.httpOptions);
 }

 geta25():Observable<Message[]>{
  const newurl = `${this.baseurl}/readabove`;
  return this.http.get<Message[]>(newurl);
 }

 dela25(id:number):Observable<boolean>{
  const newurl = `${this.baseurl}/deleteamsg/${id}`;
  return this.http.get<boolean>(newurl);
 }

 getauser():Observable<User[]>{
  const newurl = `${this.baseurl}/auser`;
  return this.http.get<User[]>(newurl);
 }


 delete(mail:string):Observable<boolean>{
   const newurl = `${this.baseurl}/delete/${mail}`
   return this.http.get<boolean>(newurl);
 }

 detail(mail:string):Observable<NewUser>{
  const newurl = `${this.baseurl}/detail/${mail}`
  return this.http.get<NewUser>(newurl);
 }

//FIle related operations

 pushabovefile(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const req = new HttpRequest('POST', `${this.baseurl}/abovefile/upload`, formdata, {
    reportProgress: true,
    responseType: 'text'
    });
    return this.http.request(req);
  }
 
 getaboveFiles(): Observable<any> {
   const newurl = `${this.baseurl}/abovefile/all`;
   return this.http.get(newurl);
  }

 deleteabovefile(id:number):Observable<any>{
    const newurl = `${this.baseurl}/abovefiledelete/${id}`;
    return this.http.get(newurl);
  }

 pushbelowfile(file: File): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const req = new HttpRequest('POST', `${this.baseurl}/belowfile/upload`, formdata, {
    reportProgress: true,
    responseType: 'text'
    });
    return this.http.request(req);
  }
 
 getbelowFiles(): Observable<any> {
   const newurl = `${this.baseurl}/belowfile/all`;
   return this.http.get(newurl);
  }

 deletebelowfile(id:number):Observable<any>{
    const newurl = `${this.baseurl}/belowfiledelete/${id}`;
    return this.http.get(newurl);
  }





}
