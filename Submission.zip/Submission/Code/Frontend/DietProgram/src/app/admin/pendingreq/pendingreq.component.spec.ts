import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PendingreqComponent } from './pendingreq.component';

describe('PendingreqComponent', () => {
  let component: PendingreqComponent;
  let fixture: ComponentFixture<PendingreqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PendingreqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PendingreqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
