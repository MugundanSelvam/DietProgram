import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AbovefilesComponent } from './abovefiles.component';

describe('AbovefilesComponent', () => {
  let component: AbovefilesComponent;
  let fixture: ComponentFixture<AbovefilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AbovefilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AbovefilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
