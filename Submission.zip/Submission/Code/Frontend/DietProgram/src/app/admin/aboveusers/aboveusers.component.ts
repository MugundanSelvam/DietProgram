import { DietserviceService } from './../../dietservice.service';
import { User } from 'src/app/User';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aboveusers',
  templateUrl: './aboveusers.component.html',
  styleUrls: ['./aboveusers.component.css']
})
export class AboveusersComponent implements OnInit {

  private umails: User[];

  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
    this.dietservice.getauser().subscribe(resp=>{
      this.umails=resp;
    })
  }

}
