import { FormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { RouterModule } from '@angular/router';
import { AllusersComponent } from './allusers/allusers.component';
import { PendingreqComponent } from './pendingreq/pendingreq.component';
import { Below25Component } from './below25/below25.component';
import { BelowusersComponent } from './belowusers/belowusers.component';
import { Above25Component } from './above25/above25.component';
import { AboveusersComponent } from './aboveusers/aboveusers.component';
import { AbovefilesComponent } from './abovefiles/abovefiles.component';
import { BelowfilesComponent } from './belowfiles/belowfiles.component';
import { UserdetailComponent } from './userdetail/userdetail.component';
import { SearchByMailPipe } from './search-by-mail.pipe';



@NgModule({
  declarations: [AdminhomeComponent, AllusersComponent, PendingreqComponent, Below25Component, BelowusersComponent, Above25Component, AboveusersComponent, AbovefilesComponent, BelowfilesComponent, UserdetailComponent, SearchByMailPipe],
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forRoot([
      {path:'adminhome',component:AdminhomeComponent,
                children:[
                          {path:'',component:PendingreqComponent},
                          {path:'allUser',component:AllusersComponent},
                          {path:'requests',component:PendingreqComponent},
                          {path:'below25',component:Below25Component},
                          {path:'above25',component:Above25Component},
                          {path:'userdetail/:id',component:UserdetailComponent},
                          {path:'allUser/userdetail/:id',component:UserdetailComponent},
                          {path:'requests/userdetail/:id',component:UserdetailComponent}
                         ]
        }
     ])
  ]
})
export class AdminModule { }
