import { DietserviceService } from './../../dietservice.service';
import { Observable } from 'rxjs';
import { Component, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-belowfiles',
  templateUrl: './belowfiles.component.html',
  styleUrls: ['./belowfiles.component.css']
})
export class BelowfilesComponent implements OnInit {
  selectedFiles: FileList;
  currentFileUpload: File;
  
  showFile = false;
  fileUploads: Observable<string[]>;
  
  constructor(private dietService: DietserviceService) { }
 
  ngOnInit() {
    this.fileUploads = this.dietService.getbelowFiles();
  }
 
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 
  upload() {
   
 
    this.currentFileUpload = this.selectedFiles.item(0);
    this.dietService.pushbelowfile(this.currentFileUpload).subscribe(event => {
    
      this.ngOnInit();
    });
    this.selectedFiles = undefined;
  }

  deletefile(id:number){
    if(confirm("Are you sure, you want to delete this file ?")) {
    this.dietService.deletebelowfile(id).subscribe(resp=>{
        this.ngOnInit();
    });
  }
  }
 
}
