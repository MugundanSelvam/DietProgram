import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AboveusersComponent } from './aboveusers.component';

describe('AboveusersComponent', () => {
  let component: AboveusersComponent;
  let fixture: ComponentFixture<AboveusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AboveusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AboveusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
