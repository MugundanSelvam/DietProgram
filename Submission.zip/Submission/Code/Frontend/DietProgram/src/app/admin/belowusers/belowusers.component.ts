import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/User';

@Component({
  selector: 'app-belowusers',
  templateUrl: './belowusers.component.html',
  styleUrls: ['./belowusers.component.css']
})
export class BelowusersComponent implements OnInit {

  private umails: User[];

  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
    this.dietservice.getbuser().subscribe(resp=>{
      this.umails=resp;
    })
  }

}
