import { Message } from './../../Message';
import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/User';

@Component({
  selector: 'app-below25',
  templateUrl: './below25.component.html',
  styleUrls: ['./below25.component.css']
})
export class Below25Component implements OnInit {

  alltexts:Message[];
  default:string;
  loggedin:string;

  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
        this.dietservice.getb25().subscribe(resp=>{
        this.alltexts=resp;
    })
    this.loggedin=this.dietservice.getLoggedin();
  }

  submit(message:string)
  {
      this.dietservice.addb25(message).subscribe(resp=>{
        if(resp){
          this.default='';      
          this.ngOnInit();
        }
      });
  }


  deletemsg(id:number){
    if(confirm("Are you sure, you want to delete this Message ?")) {
    this.dietservice.delb25(id).subscribe(resp=>{
      if(resp){
        this.ngOnInit();
      }
    })
   }
  }

}
