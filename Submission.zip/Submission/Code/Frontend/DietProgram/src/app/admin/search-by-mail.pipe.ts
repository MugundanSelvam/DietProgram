import { Pipe, PipeTransform } from '@angular/core';
import { NewUser } from '../NewUser';

@Pipe({
  name: 'searchByMail'
})
export class SearchByMailPipe implements PipeTransform {

  transform( users :NewUser[], searchTerm :string ): NewUser[] {
    if (!users || !searchTerm) {
      return users;
    }

    return users.filter(user =>
      user.mail.toLowerCase().startsWith(searchTerm.toLowerCase())
    );
  }

}
