import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BelowusersComponent } from './belowusers.component';

describe('BelowusersComponent', () => {
  let component: BelowusersComponent;
  let fixture: ComponentFixture<BelowusersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BelowusersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BelowusersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
