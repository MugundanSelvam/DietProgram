import { Router } from '@angular/router';
import { DietserviceService } from './../../dietservice.service';
import { UserReq } from './../../UserReq';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pendingreq',
  templateUrl: './pendingreq.component.html',
  styleUrls: ['./pendingreq.component.css']
})
export class PendingreqComponent implements OnInit {

  private users:UserReq[];

  constructor(private dietservice:DietserviceService,private router:Router) { }

  ngOnInit() {
    this.dietservice.getreq().subscribe(resp=>{
      this.users=resp;
    })
  }

  approve(user:UserReq){
    this.dietservice.approve(user).subscribe(resp=>{
      if(resp){
        this.ngOnInit();
      }
    });
  }
  
  reject(user:UserReq){
    if(confirm("Are you sure? This will Reject the User Request.")) {
      this.dietservice.reject(user).subscribe(resp=>{
        if(resp){
          this.ngOnInit();
        }
      });
    }
  }
}
