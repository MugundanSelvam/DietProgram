import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BelowfilesComponent } from './belowfiles.component';

describe('BelowfilesComponent', () => {
  let component: BelowfilesComponent;
  let fixture: ComponentFixture<BelowfilesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BelowfilesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BelowfilesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
