import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { NewUser } from 'src/app/NewUser';

@Component({
  selector: 'app-allusers',
  templateUrl: './allusers.component.html',
  styleUrls: ['./allusers.component.css']
})
export class AllusersComponent implements OnInit {

  searchText :string;
  users :NewUser[];
  bmi : number;

  constructor(private dietservice :DietserviceService) {
  }
  
  ngOnInit() {
    this.dietservice.getallusers().subscribe(resp => {
      this.users=resp;
      })
  }

  delete(mail:string){
    if(confirm("Are you sure, you want to delete the User ?")) {
    this.dietservice.delete(mail).subscribe(resp=>{
      if(resp)
      {
        this.ngOnInit();
      }
    });
  }
  }

  permission(mail:string,type:string){
    this.dietservice.promote(mail,type).subscribe(resp=>{
      if(resp)
      this.ngOnInit();
    });
  }

}
