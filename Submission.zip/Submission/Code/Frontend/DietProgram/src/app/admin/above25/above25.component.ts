import { Message } from './../../Message';
import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-above25',
  templateUrl: './above25.component.html',
  styleUrls: ['./above25.component.css']
})
export class Above25Component implements OnInit {

  alltexts:Message[];
  default:string;
  loggedin:string;

  constructor(private dietservice:DietserviceService) { }

  ngOnInit() {
        this.dietservice.geta25().subscribe(resp=>{
        this.alltexts=resp;
    })
    this.loggedin=this.dietservice.getLoggedin();
  }

  submit(message:string)
  {
      this.dietservice.adda25(message).subscribe(resp=>{
        if(resp){
          this.default='';      
          this.ngOnInit();
        }
      });
  }

  deletemsg(id:number){
    if(confirm("Are you sure, you want to delete this Message ?")) {
    this.dietservice.dela25(id).subscribe(resp=>{
      if(resp){
        this.ngOnInit();
      }
    })
   }
  }

}
