import { Observable } from 'rxjs';
import { DietserviceService } from './../../dietservice.service';
import { Component, OnInit } from '@angular/core';
import { HttpEventType, HttpResponse } from '@angular/common/http';

@Component({
  selector: 'app-abovefiles',
  templateUrl: './abovefiles.component.html',
  styleUrls: ['./abovefiles.component.css']
})
export class AbovefilesComponent implements OnInit {

  selectedFiles: FileList;
  currentFileUpload: File;
 

  showFile = false;
  fileUploads: Observable<string[]>;
  
  constructor(private dietService: DietserviceService) { }
 
  ngOnInit() {
    this.fileUploads = this.dietService.getaboveFiles();
  }
 
  selectFile(event) {
    this.selectedFiles = event.target.files;
  }
 
  upload() {
    this.currentFileUpload = this.selectedFiles.item(0);
    this.dietService.pushabovefile(this.currentFileUpload).subscribe(event => {
      this.ngOnInit();
    });
    this.selectedFiles = undefined;
  }

  deletefile(id:number){
    if(confirm("Are you sure, you want to delete this file ?")) {
    this.dietService.deleteabovefile(id).subscribe(resp=>{
        this.ngOnInit();
    });
  }
  }
 
}
