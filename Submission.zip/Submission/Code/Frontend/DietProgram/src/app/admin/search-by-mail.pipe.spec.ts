import { SearchByMailPipe } from './search-by-mail.pipe';

describe('SearchByMailPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchByMailPipe();
    expect(pipe).toBeTruthy();
  });
});
