import { DietserviceService } from './../../dietservice.service';
import { NewUser } from './../../NewUser';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common'

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {

  user:NewUser;
  constructor(private route:ActivatedRoute,
    private dietService:DietserviceService,
    private location: Location) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.dietService.detail(id).subscribe(resp=>{
      this.user=resp;
    });
  }

  goback(){
   this.location.back();
  }

}
