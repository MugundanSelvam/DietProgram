import { DietserviceService } from './../dietservice.service';
import { User } from './../User';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {

  invalid:boolean;
  notregistered:boolean;
  constructor(private dietservice : DietserviceService, private router:Router) { }

  submit(user:User):void{
  this.dietservice.checkcred(user).subscribe(resp=>{
    if(resp==1)
    {
      this.dietservice.setPermission("admin");
      this.router.navigate(['/adminhome']);
    }
    else if(resp==2) 
    {
      this.dietservice.setPermission("user");
      this.router.navigate(['/userhome']);
    }
    else if(resp==5){
      this.dietservice.setPermission("moderator");
      this.router.navigate(['/userhome']);
    }
    else if(resp==3)
    {
     this.notregistered=false;
     this.invalid=true;
    }
    else if(resp==4)
    {
      this.invalid=false;
      this.notregistered=true;
    }
  })
  }
  
}
